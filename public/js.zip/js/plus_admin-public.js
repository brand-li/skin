<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<title>Page not found &#8211; Plus Admin</title>
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Plus Admin &raquo; Feed" href="http://demo.castorstudio.com/plus-wordpress-admin-theme/feed/" />
<link rel="alternate" type="application/rss+xml" title="Plus Admin &raquo; Comments Feed" href="http://demo.castorstudio.com/plus-wordpress-admin-theme/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/demo.castorstudio.com\/plus-wordpress-admin-theme\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.5"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/css/dist/block-library/style.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/css/dist/block-library/theme.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='cst-castor-line-icons-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/plugins/plus_admin-1.0.2-rc/icons/castor-line-icons/castor-line-icons.css?ver=1.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/plugins/plus_admin-1.0.2-rc/icons/fontawesome/fontawesome.css?ver=5.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='plus_admin-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/plugins/plus_admin-1.0.2-rc/public/css/plus_admin-public.css?ver=1.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='twentynineteen-style-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/themes/twentynineteen/style.css?ver=1.4' type='text/css' media='all' />
<link rel='stylesheet' id='twentynineteen-print-style-css'  href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/themes/twentynineteen/print.css?ver=1.4' type='text/css' media='print' />
<script type='text/javascript' src='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-content/plugins/plus_admin-1.0.2-rc/public/js/plus_admin-public.js?ver=1.0.2'></script>
<link rel='https://api.w.org/' href='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://demo.castorstudio.com/plus-wordpress-admin-theme/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/wlwmanifest.xml" /> 
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		</head>

<body class="error404 wp-embed-responsive hfeed image-filters-enabled">
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

		<header id="masthead" class="site-header">

			<div class="site-branding-container">
				<div class="site-branding">

								<p class="site-title"><a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/" rel="home">Plus Admin</a></p>
			
				<p class="site-description">
				WordPress White Label Branding Admin Theme			</p>
			</div><!-- .site-branding -->
			</div><!-- .site-branding-container -->

					</header><!-- #masthead -->

	<div id="content" class="site-content">

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

			<div class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try a search?</p>
					<form role="search" method="get" class="search-form" action="http://demo.castorstudio.com/plus-wordpress-admin-theme/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>				</div><!-- .page-content -->
			</div><!-- .error-404 -->

		</main><!-- #main -->
	</section><!-- #primary -->


	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		
	<aside class="widget-area" role="complementary" aria-label="Footer">
							<div class="widget-column footer-widget-1">
					<section id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="http://demo.castorstudio.com/plus-wordpress-admin-theme/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></section>		<section id="recent-posts-2" class="widget widget_recent_entries">		<h2 class="widget-title">Recent Posts</h2>		<ul>
											<li>
					<a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/2019/07/17/hello-world/">Welcome to Plus Admin</a>
									</li>
					</ul>
		</section><section id="recent-comments-2" class="widget widget_recent_comments"><h2 class="widget-title">Recent Comments</h2><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='https://wordpress.org/' rel='external nofollow' class='url'>A WordPress Commenter</a></span> on <a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/2019/07/17/hello-world/#comment-1">Welcome to Plus Admin</a></li></ul></section><section id="archives-2" class="widget widget_archive"><h2 class="widget-title">Archives</h2>		<ul>
				<li><a href='http://demo.castorstudio.com/plus-wordpress-admin-theme/2019/07/'>July 2019</a></li>
		</ul>
			</section><section id="categories-2" class="widget widget_categories"><h2 class="widget-title">Categories</h2>		<ul>
				<li class="cat-item cat-item-1"><a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/category/uncategorized/">Uncategorized</a>
</li>
		</ul>
			</section><section id="meta-2" class="widget widget_meta"><h2 class="widget-title">Meta</h2>			<ul>
						<li><a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/plus-admin-login">Log in</a></li>
			<li><a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/feed/">Entries <abbr title="Really Simple Syndication">RSS</abbr></a></li>
			<li><a href="http://demo.castorstudio.com/plus-wordpress-admin-theme/comments/feed/">Comments <abbr title="Really Simple Syndication">RSS</abbr></a></li>
			<li><a href="https://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress.org</a></li>			</ul>
			</section>					</div>
					</aside><!-- .widget-area -->

		<div class="site-info">
										<a class="site-name" href="http://demo.castorstudio.com/plus-wordpress-admin-theme/" rel="home">Plus Admin</a>,
						<a href="https://wordpress.org/" class="imprint">
				Proudly powered by WordPress.			</a>
								</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<script type='text/javascript' src='http://demo.castorstudio.com/plus-wordpress-admin-theme/wp-includes/js/wp-embed.min.js?ver=5.2.5'></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	
</body>
</html>
